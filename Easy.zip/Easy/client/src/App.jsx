import Categories from "./CenterPage/Categories/Categories";
import Home from "./CenterPage/Pages/Home";
import TopSection from "./CenterPage/TopSection/TopSection";

function App() {
  return (
    <>
      {/* <TopSection />
      <Categories /> */}
      <Home />
    </>
  );
}

export default App;
